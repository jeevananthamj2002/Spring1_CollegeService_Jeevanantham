package com.tnsif.placement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tnsif.placement.entity.College;

public interface CollegeRepository extends JpaRepository<College, Long>{

}
